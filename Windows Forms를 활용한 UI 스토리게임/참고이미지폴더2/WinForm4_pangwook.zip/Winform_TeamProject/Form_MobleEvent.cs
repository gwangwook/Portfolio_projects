﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Winform_TeamProject
{
    public partial class Form_MobleEvent : Form
    {
        public static int i = 10;

        public Form_MobleEvent()
        {
            InitializeComponent();

        }

        private void btn_HidingHint_Click(object sender, EventArgs e)
        {
            Form_MobleHint1 form_MobleHint1 = new Form_MobleHint1();
            form_MobleHint1.ShowDialog();

        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_SignIn_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "21")
            {
                MessageBox.Show("열렸습니다!");
                Form_Moble_ComputerScreen form_Moble_ComputerScreen = new Form_Moble_ComputerScreen();
                form_Moble_ComputerScreen.Show();
                this.Close();
            }
            else
            {
                if (textBox1.Text == "")
                {
                    MessageBox.Show("비밀번호를 입력해주세요!");
                    return;
                }
                if (i > 1)
                {
                    i--;
                    MessageBox.Show($"틀렸습니다. 입력 기회가 {i}회 남았습니다.");
                    return;
                }
                else if (i == 1)
                {
                    i--;
                    MessageBox.Show("틀렸습니다. 모든 기회를 소진하셨습니다.\n잠금모드를 활성화합니다.\n" +
                        "잠금 해제하시려면 관리자에게 문의해주세요.\n010-1111-2222");
                    return;
                }
                else
                {
                    MessageBox.Show("비밀번호를 10회 틀려 잠금모드가 활성화되어 있습니다.\n" +
                        "잠금 해제하시려면 관리자에게 문의해주세요.\n010-1111-2222");
                }
            }
        }
    }
}
