﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;


namespace Winform_TeamProject
{
    public partial class Form_Moble : Form
    {
        static public List<string> moble_commu = new List<string>();

        int moble_text_index = 0;

        public Form_Moble()
        {
            InitializeComponent();
            moble_commu.Add("(드디어 학원에 도착했다.)");
            moble_commu.Add("(...?)");
            moble_commu.Add("(평소에도 으스스하던 학원 입구가 오늘따라 더 음침해보인다..)");
            moble_commu.Add("...");
            moble_commu.Add("(앞에 먼저 건물에 도착한 학생이 보인다.)");
            moble_commu.Add("어? 태운이니?");    //5
            moble_commu.Add("(반가운 마음에 다가가 인사를 건네지만 \n그는 누가봐도 수상한 사람과 함께 계단을 내려간다.)");
            moble_commu.Add("학생이.. 무시..?\n(옆에 있는 사람은 누구지? 처음 보는 것 같은데...)");
            moble_commu.Add("(먼저 올라가야겠다.\n우리 학원은 3층인데.. 이상하네 왜 내려가지?)");
            moble_commu.Add("System : 엘리베이터에 탑승합니다.");
            moble_commu.Add("System : 학원에 입장하였습니다.");   //10    //배경 바꾸기(학원)
            moble_commu.Add("(학생이 아무도 없다.)");
            moble_commu.Add("어? 시간이 몇신데 아무도 없지..? (무언가 이상하다.)");
            moble_commu.Add("(학생들이 모두 연락을 받지 않는다.)");
            moble_commu.Add("아까 계단으로 내려간 태운이를 찾으러 가봐야하나?");
            moble_commu.Add("System : 지하 1층을 가보시겠습니까?");    //15     //y/n 버튼 만들기
            moble_commu.Add("아니다. 10분만 기다려보자.");
            moble_commu.Add("System : 10분 경과 후...");
            moble_commu.Add("(안되겠다! 내려가보자!)");
            moble_commu.Add("System : 지하로 내려갑니다.");     
            moble_commu.Add("(내려오자마자 큰 철문이 보인다. 확인해보자.)");    //20    //배경 바꾸기(지하)
            moble_commu.Add("알아들었어!? 너네는 그냥 배달만 하면 돼!\n실수하면.. 알지?");    //마약 브로커 캐릭터 대사 
            moble_commu.Add("(누군가가 학생들을 위협하고 있다. 배달이라니, 혹시.. 마약..?)");
            moble_commu.Add("System : 이 곳은 마약을 밀수해 국내에서 마약거래를 하는 조직입니다.");
            moble_commu.Add("System : 어떻게 하시겠습니까?");    // 경찰에 신고 or 도망 버튼
            moble_commu.Add("(경찰에 신고하자..!)");   //25
            moble_commu.Add("System : 경찰에 신고하려면 증거가 필요합니다.\n증거를 찾으세요.");
            moble_commu.Add("(앞에 브로커의 방이 보인다. 탐색해보자.)");
            moble_commu.Add("(몰래 들어오니 컴퓨터가 눈에 띈다.\n컴퓨터에 증거가 될만한 것이 있지 않을까?\n" +
                "컴퓨터를 켜보자.)");   //컴퓨터 키기 버튼 visible = true;
            moble_commu.Add("");    //브로커의 콤퓨타 이벤트 발생
            moble_commu.Add("");
        }
        private async Task DisplayTextWithDelay(string text, Label label, int delay)
        {
            for (int i = 0; i < text.Length; i++)
            {
                label.Text += text[i].ToString();
                await Task.Delay(delay);
            }
        }

        private void btn_GoEvent1_Click(object sender, EventArgs e)
        {
            Form_MobleEvent form_MobleEvent = new Form_MobleEvent();
            form_MobleEvent.ShowDialog();
        }

        private async void Text_Panel_MouseDown(object sender, MouseEventArgs e)
        {
            if (moble_text_index + 1 <= moble_commu.Count)
            {
                label1.Text = "";
                string text = moble_commu[moble_text_index];
                moble_text_index++;
                await DisplayTextWithDelay(text, label1, 10);

            }
        }
    }
}
