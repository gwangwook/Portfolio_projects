﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Winform_TeamProject
{
    public partial class Form_Moble_ComputerScreen : Form
    {
        public Form_Moble_ComputerScreen()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("잘못 누르셨습니다!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("파일을 USB에 복사합니다!");
            progressBar1.Visible = true;
            timer1.Interval = 30;
            timer1.Start();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("잘못 누르셨습니다!");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("시스템 종료");
            this.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            progressBar1.Value++;
            if (progressBar1.Value == 100)
            {
                timer1.Stop();
                MessageBox.Show("복사가 완료되었습니다!");
                this.Close() ;
            }
        }
    }
}
