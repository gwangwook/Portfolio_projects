﻿namespace Winform_TeamProject
{
    partial class Form_Moble
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Moble));
            btn_GoEvent1 = new System.Windows.Forms.Button();
            Text_Panel = new System.Windows.Forms.Panel();
            pictureBox2 = new System.Windows.Forms.PictureBox();
            label1 = new System.Windows.Forms.Label();
            pictureBox1 = new System.Windows.Forms.PictureBox();
            Text_Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // btn_GoEvent1
            // 
            btn_GoEvent1.Location = new System.Drawing.Point(1021, 589);
            btn_GoEvent1.Name = "btn_GoEvent1";
            btn_GoEvent1.Size = new System.Drawing.Size(104, 64);
            btn_GoEvent1.TabIndex = 1;
            btn_GoEvent1.Text = "문제풀러가기";
            btn_GoEvent1.UseVisualStyleBackColor = true;
            btn_GoEvent1.Click += btn_GoEvent1_Click;
            // 
            // Text_Panel
            // 
            Text_Panel.BackColor = System.Drawing.Color.Transparent;
            Text_Panel.BackgroundImage = (System.Drawing.Image)resources.GetObject("Text_Panel.BackgroundImage");
            Text_Panel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            Text_Panel.Controls.Add(pictureBox2);
            Text_Panel.Controls.Add(label1);
            Text_Panel.Location = new System.Drawing.Point(69, 659);
            Text_Panel.Name = "Text_Panel";
            Text_Panel.Size = new System.Drawing.Size(1056, 152);
            Text_Panel.TabIndex = 13;
            Text_Panel.MouseDown += Text_Panel_MouseDown;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (System.Drawing.Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new System.Drawing.Point(952, 46);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new System.Drawing.Size(82, 93);
            pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 11;
            pictureBox2.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = System.Drawing.Color.Transparent;
            label1.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(30, 20);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(0, 40);
            label1.TabIndex = 10;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = System.Drawing.Color.Transparent;
            pictureBox1.Image = (System.Drawing.Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new System.Drawing.Point(46, 506);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new System.Drawing.Size(258, 170);
            pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 12;
            pictureBox1.TabStop = false;
            // 
            // Form_Moble
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(1184, 861);
            Controls.Add(Text_Panel);
            Controls.Add(pictureBox1);
            Controls.Add(btn_GoEvent1);
            Name = "Form_Moble";
            StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            Text = "Form_Moble";
            Text_Panel.ResumeLayout(false);
            Text_Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private System.Windows.Forms.Button btn_GoEvent1;
        private System.Windows.Forms.Panel Text_Panel;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}